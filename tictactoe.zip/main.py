import pygame
pygame.init()

screenWidth = 475
screenHeight = 550
#Creates a window for the game
window = pygame.display.set_mode((screenWidth, screenHeight))

#Sets the title of the window
pygame.display.set_caption('Tic-Tac-Toe in the Sea')

green = (0, 255, 0) 
blue = (35, 143, 255)
white = (255, 255, 255)
black = (0,0,0)

board = [[0,0,0], [0,0,0], [0,0,0]] 
#pos [(0,0), (0,1), (0,2),(1,0), (1,1), (1,2), (2,0), (2,1), (2,2)]

open_tiles = [0, 0, 0, 0, 0, 0, 0, 0, 0]

background_image = pygame.image.load('water3.png').convert()
window.blit(background_image, [0, 0])
pygame.display.flip()  

class Tile(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([125, 125])
        self.image.set_alpha(128)
        self.image.fill(white)
        self.rect = self.image.get_rect()
    
tile_list = pygame.sprite.Group()

for row in range(3):
    for column in range(3):
        tile = Tile()
        tile.rect.x = 25 + 150 * row
        tile.rect.y = 100 + 150 * column
        tile_list.add(tile)
tile_list.draw(window)
    
def redraw():
    pygame.display.update()

# create a font object. 
# (1st parameter is the font file, 2nd parameter is size of the font)
font = pygame.font.Font('freesansbold.ttf', 55) 
winFont = pygame.font.Font('freesansbold.ttf', 65)
font2 = pygame.font.Font('freesansbold.ttf', 60)
# create a text suface object, on which text is drawn on it.
fishText = font.render("Fish's Turn", True, white, blue) 
octoText = font.render("Octopus' Turn", True, white, blue)
labelO = font.render("Octopus' Turn", 0, blue, blue)
labelF = font.render("Fish's Turn", 0, blue, blue)

fish_win_text = winFont.render('  Fish won!  ', True, white,blue)
octo_win_text = winFont.render('Octopus won!', True, white,blue)

tieText = winFont.render('        Tie!        ', True, white, blue)

# create a rectangular object for the text surface object 
fishTextRect = fishText.get_rect()
octoTextRect = octoText.get_rect()  

fishWinRect = fish_win_text.get_rect()
octoWinRect = octo_win_text.get_rect()
tieRect = tieText.get_rect()

# set the center of the rectangular object. 
fishTextRect.center = (230, 45)
octoTextRect.center = (230, 45)

fishWinRect.center = (230, 45)
octoWinRect.center = (238, 45)
tieRect.center = (230, 45)

#Sets the first player's shape
draw_object = 'fish'
window.blit(fishText, fishTextRect)

fishImg = pygame.image.load('bluefish.png')
FISH_SMALL = pygame.transform.scale(fishImg, (90, 40))
octopusImg = pygame.image.load('octopus.png')
OCTO_SMALL = pygame.transform.scale(octopusImg, (110,90))

def win_check(num):
    for row in board:
        for tile in row:
            if tile == num:
                continue
            else:
                break
        else:
            return True

    for column in range(3):
        for row in board:
            if row[column] == num:
                continue
            else:
                break
        else:
            return True

    for tile in range(3):
        if board[tile][tile] == num:
            continue
        else:
            break
    else:
        return True

    for tile in range(3):
        if board[tile][2 - tile] == num:
            continue
        else:
            break
    else:
        return True

    return False

#Main Loop
won = False
run = True
while run:

  #Refresh time
  pygame.time.delay(100)

  #pygame events
  for event in pygame.event.get():

    #Quit Event
    if event.type == pygame.QUIT:
      run = False

    #To see which space is clicked 
    if event.type == pygame.MOUSEBUTTONUP:
      pos = pygame.mouse.get_pos()

      if won != True:
        #Checks if mouse position is in a space
        first = tile_list.sprites()[0]
        if first.rect.collidepoint(pos) and open_tiles[0] == 0:
          #Draw a shape based on which player's turn it is
          if draw_object == 'fish':
            #surface.blit(image,(x-coordinate, y-coordinate))
            window.blit(FISH_SMALL,(40, 140))
            window.blit(labelF, fishTextRect)       
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[0][0] = 1
          else:
            window.blit(OCTO_SMALL, (30,120))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[0][0] = 2
            #marks this space as taken 
          open_tiles[0] = 1 # 0 is when a tile is open 
                            #1 is when a tile is taken

        second = tile_list.sprites()[3]
        if second.rect.collidepoint(pos) and open_tiles[1] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(190, 140))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[0][1] = 1

          else:
            window.blit(OCTO_SMALL, (180,120))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[0][1] = 2
          open_tiles[1] = 1

        third = tile_list.sprites()[6]              
        if third.rect.collidepoint(pos) and open_tiles[2] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(340, 140))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[0][2] = 1
          else:
            window.blit(OCTO_SMALL, (330,120))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[0][2] = 2
          open_tiles[2] = 1

        fourth = tile_list.sprites()[1]
        if fourth.rect.collidepoint(pos) and open_tiles[3] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(40, 290))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[1][0] = 1
          else:
            window.blit(OCTO_SMALL, (30,270))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[1][0] = 2
          open_tiles[3] = 1

        fifth = tile_list.sprites()[4]                 
        if fifth.rect.collidepoint(pos) and open_tiles[4] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(190, 290))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[1][1] = 1
          else:
            window.blit(OCTO_SMALL, (180,270))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[1][1] = 2
          open_tiles[4] = 1

        sixth = tile_list.sprites()[7]                  
        if sixth.rect.collidepoint(pos) and open_tiles[5] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(340, 290))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[1][2] = 1
          else:
            window.blit(OCTO_SMALL, (330,270))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[1][2] = 2
          open_tiles[5] = 1

        seventh = tile_list.sprites()[2]
        if seventh.rect.collidepoint(pos) and open_tiles[6] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(40, 440))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[2][0] = 1
          else:
            window.blit(OCTO_SMALL, (30,420))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[2][0] = 2
          open_tiles[6] = 1

        eighth = tile_list.sprites()[5]
        if eighth.rect.collidepoint(pos) and open_tiles[7] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(190, 440))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[2][1] = 1
          else:
            window.blit(OCTO_SMALL, (180,420))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[2][1] = 2
          open_tiles[7] = 1

        ninth = tile_list.sprites()[8]                 
        if ninth.rect.collidepoint(pos) and open_tiles[8] == 0:
          if draw_object == 'fish':
            window.blit(FISH_SMALL,(340, 440))
            window.blit(labelF, fishTextRect)
            window.blit(octoText, octoTextRect)
            draw_object = 'octo'
            board[2][2] = 1
          else:
            window.blit(OCTO_SMALL, (330,420))
            window.blit(labelO, octoTextRect)
            window.blit(fishText, fishTextRect)
            draw_object = 'fish'
            board[2][2] = 2
          open_tiles[8] = 1

    if win_check(1): #if Fish won
      won = True
      window.blit(fish_win_text, fishWinRect) 
    if win_check(2): #if Octopus won
      won = True
      window.blit(octo_win_text, octoWinRect) 

    tie = False

    if len(open_tiles) > 0:
      tie = all(elem == 1 for elem in open_tiles)

    if tie == True and win_check(1) == False and win_check(2) == False:
      won = True
      window.blit(tieText, tieRect)

    if won == True:
      playAgainFont = pygame.font.Font('freesansbold.ttf', 80)
      play_again_text = playAgainFont.render('Play Again', True, white, blue)
      playAgainRect = play_again_text.get_rect()
      playAgainRect.center = (screenWidth//2, screenHeight//2)
      window.blit(play_again_text, playAgainRect)

      if event.type == pygame.MOUSEBUTTONUP:
        pos = pygame.mouse.get_pos()

        if playAgainRect.collidepoint(pos):
          run = True
          won = False
          tie = False
          board = [[0,0,0], [0,0,0], [0,0,0]]
          open_tiles = [0, 0, 0, 0, 0, 0, 0, 0, 0]
          window.blit(background_image, [0, 0])
          pygame.display.flip()

          #Redraw the game board
          tile_list.draw(window)
          
          draw_object = 'fish'
          window.blit(labelO, octoTextRect)
          window.blit(fishText, fishTextRect)
                    
  
   #Updates screen with new shapes
    redraw()

#Closes game once loop is broken
pygame.quit() 
